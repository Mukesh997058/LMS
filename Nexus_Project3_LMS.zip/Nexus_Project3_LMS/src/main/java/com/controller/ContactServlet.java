package com.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import com.bean.*;
import com.dao.*;

/**
 * Servlet implementation class ContactServlet
 */
public class ContactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContactServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String name=request.getParameter("name");
			String scname=request.getParameter("scname");
			String sclocation=request.getParameter("sclocation");
			String email=request.getParameter("email");
			String contactno1=request.getParameter("contactno");

			int contactno=Integer.parseInt(contactno1);

			PrintWriter out=response.getWriter();
			RequestDispatcher rd1=request.getRequestDispatcher("./contactSuccess.jsp");
			RequestDispatcher rd2=request.getRequestDispatcher("./contact.jsp");
			response.setContentType("text/html");
			contact cobj=new contact();
			cobj.setName(name);
			cobj.setScname(scname);
			cobj.setScname(sclocation);
			cobj.setEmail(email);
			cobj.setContactno(contactno);
			
			ContactDao condao=new ContactDao();
			String result;
			try {
				result=condao.contact(cobj);
				if(result.equals("success"))
				{
					rd1.forward(request, response);
				}
				else
				{
					out.print("Invalid username or password...");
					rd2.include(request, response);
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			
			}
	}

}
