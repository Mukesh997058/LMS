package com.controller;
import com.bean.*;
import com.dao.*;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Servlet implementation class AddBookServlet
 */
public class AddBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddBookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String bname=request.getParameter("bname");
			String aname=request.getParameter("aname");
			String price1=request.getParameter("price");
			int price=Integer.parseInt(price1);
			String pubbname=request.getParameter("pubname");

			PrintWriter out=response.getWriter();
			RequestDispatcher rd1=request.getRequestDispatcher("./Home.jsp");
			RequestDispatcher rd2=request.getRequestDispatcher("./Login.html");
			response.setContentType("text/html");
			BookBean bobj=new BookBean();
			bobj.setBname(bname);
			bobj.setAname(aname);
			bobj.setPrice(price);
			bobj.setPubname(pubbname);
			
			BookDao Bgndao=new BookDao();
			String result;
			try {
				result=Bgndao.addbook(bobj);
				if(result.equals("success"))
				{
					rd1.forward(request, response);
				}
				else
				{
					out.print("Invalid username or password...");
					rd2.include(request, response);
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			
			}
			
		
	}

}
