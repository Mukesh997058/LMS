package com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class ShowAllBookServlet
 */
public class ShowAllBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowAllBookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	try
    			
    			{
    				Class.forName("com.mysql.jdbc.Driver");
    				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/java_db","root","Root@123");
    				HttpSession session=request.getSession();
  
    				PrintWriter out=response.getWriter();
    				PreparedStatement ps= con.prepareStatement("select bookname,authorname,publication_name,price from booktable");
    				
    				ResultSet rs=ps.executeQuery();
    				out.print("<html>\r\n"
    						+ "<head>\r\n"
    						+ "    <meta charset=\"UTF-8\">\r\n"
    						+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n"
    						+ "    <title>Login Form</title>\r\n"
    						+ "    <style>\r\n"
    						+ "     \r\n"
    						+ "\r\n"
    						+ "        form {\r\n"
    						+ "            width: 300px;\r\n"
    						+ "            padding: 20px;\r\n"
    						+ "            border: 1px solid #ccc;\r\n"
    						+ "            border-radius: 5px;\r\n"
    						+ "            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);\r\n"
    						+ "        }\r\n"
    						+ "\r\n"
    						+ "        input {\r\n"
    						+ "            width: 100%;\r\n"
    						+ "            padding: 10px;\r\n"
    						+ "            margin-bottom: 10px;\r\n"
    						+ "            box-sizing: border-box;\r\n"
    						+ "        }\r\n"
    						+ "\r\n"
    						+ "        button {\r\n"
    						+ "            width: 100%;\r\n"
    						+ "            padding: 10px;\r\n"
    						+ "            background-color: #4caf50;\r\n"
    						+ "            color: white;\r\n"
    						+ "            border: none;\r\n"
    						+ "            border-radius: 5px;\r\n"
    						+ "            cursor: pointer;\r\n"
    						+ "        }\r\n"
    						+ "\r\n"
    						+ "        button:hover {\r\n"
    						+ "            background-color: #45a049;\r\n"
    						+ "        }\r\n"
    						+ "        \r\n"
    						+ "        \r\n"
    						+ "        body {\r\n"
    						+ "            font-family: Arial, sans-serif;\r\n"
    						+ "            margin: 0;\r\n"
    						+ "            padding: 0;\r\n"
    						+ "            background-color: #f4f4f4;\r\n"
    						+ "        }\r\n"
    						+ "\r\n"
    						+ "        header {\r\n"
    						+ "            background-color: #333;\r\n"
    						+ "            color: white;\r\n"
    						+ "            text-align: center;\r\n"
    						+ "            padding: 1em;\r\n"
    						+ "        }\r\n"
    						+ "\r\n"
    						+ "        nav {\r\n"
    						+ "            background-color: #444;\r\n"
    						+ "            color: white;\r\n"
    						+ "            text-align: center;\r\n"
    						+ "            padding: 0.5em;\r\n"
    						+ "        }\r\n"
    						+ "\r\n"
    						+ "        nav a {\r\n"
    						+ "            color: white;\r\n"
    						+ "            text-decoration: none;\r\n"
    						+ "            padding: 1em;\r\n"
    						+ "        }\r\n"
    						+ "\r\n"
    						+ "        section {\r\n"
    						+ "            padding: 20px;\r\n"
    						+ "            text-align: center;\r\n"
    						+ "        }\r\n"
    						+ "        ul {\r\n"
    						+ "  list-style-type: none;\r\n"
    						+ "  margin: 0;\r\n"
    						+ "  padding: 0;\r\n"
    						+ "  overflow: hidden;\r\n"
    						+ "  background-color: #333;\r\n"
    						+ " \r\n"
    						+ "}\r\n"
    						+ "\r\n"
    						+ "li {\r\n"
    						+ "  float: left;\r\n"
    						+ "   text-align: center;\r\n"
    						+ "}\r\n"
    						+ "\r\n"
    						+ "li a, .dropbtn {\r\n"
    						+ "  display: inline-block;\r\n"
    						+ "  color: white;\r\n"
    						+ "  \r\n"
    						+ "  padding: 14px 16px;\r\n"
    						+ "  text-decoration: none;\r\n"
    						+ "}\r\n"
    						+ "\r\n"
    						+ "li a:hover, .dropdown:hover .dropbtn {\r\n"
    						+ "  background-color: red;\r\n"
    						+ "}\r\n"
    						+ "\r\n"
    						+ "li.dropdown {\r\n"
    						+ "  display: inline-block;\r\n"
    						+ "}\r\n"
    						+ "\r\n"
    						+ ".dropdown-content {\r\n"
    						+ "  display: none;\r\n"
    						+ "  position: absolute;\r\n"
    						+ "  background-color: #f9f9f9;\r\n"
    						+ "  min-width: 160px;\r\n"
    						+ "  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);\r\n"
    						+ "  z-index: 1;\r\n"
    						+ "}\r\n"
    						+ "\r\n"
    						+ ".dropdown-content a {\r\n"
    						+ "  color: black;\r\n"
    						+ "  padding: 12px 16px;\r\n"
    						+ "  text-decoration: none;\r\n"
    						+ "  display: block;\r\n"
    						+ "  text-align: center;\r\n"
    						+ "}\r\n"
    						+ "\r\n"
    						+ ".dropdown-content a:hover {background-color: #f1f1f1;}\r\n"
    						+ "\r\n"
    						+ ".dropdown:hover .dropdown-content {\r\n"
    						+ "  display: block;\r\n"
    						+ "}\r\n"
    						+ "    </style>\r\n"
    						+ "     <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js\">  </script>\r\n"
    						+ "    <script type=\"text/javascript\">\r\n"
    						+ "function validate()\r\n"
    						+ "{\r\n"
    						+ "	var username=document.f1.username.value;\r\n"
    						+ "	var password=document.f1.username.value;\r\n"
    						+ "	\r\n"
    						+ "	if(username==null || username ==\"\")\r\n"
    						+ "		{\r\n"
    						+ "		alert(\"username cannot be blank\");\r\n"
    						+ "		return false;\r\n"
    						+ "		}\r\n"
    						+ "	elseif( password==null || password==\"\")\r\n"
    						+ "	{\r\n"
    						+ "		alert(\"password cannot be blank\");\r\n"
    						+ "		return false;\r\n"
    						+ "	}\r\n"
    						+ "}\r\n"
    						+ "$(document).ready(function()\r\n"
    						+ "        {\r\n"
    						+ "	 $(\"#f1\").hide();\r\n"
    						+ "	 $(\"#log\").click(function ()\r\n"
    						+ "             {\r\n"
    						+ "              $(\"#f1\").show();\r\n"
    						+ "              $(\"#im1\").hide();\r\n"
    						+ "               })\r\n"
    						+ "        }\r\n"
    						+ "        \r\n"
    						+ "</script>\r\n"
    						+ "</head>\r\n"
    						+ "<body>\r\n"
    						+ "	 <header>\r\n"
    						+ "        <h1>Library Management System</h1>\r\n"
    						+ "    </header>\r\n"
    						+ "\r\n"
    						+ " <nav>\r\n"
    						+ "    <ul>\r\n"
    						+ "  <li><a href=\"#home\">Home</a></li>\r\n"
    						+ "  <li><a href=\"#\">Books</a></li>\r\n"
    						+ "  <li><a href=\"#\">Members</a></li>\r\n"
    						+ "  <li> <a href=\"#\">Transactions</a></li>\r\n"
    						+ "  <li><a href=\"About.jsp\">About</a></li>\r\n"
    						+ "  <li> <a id=\"log\" href=\"login.jsp\">Login</a></li>\r\n"
    						+ "  <li> <a href=\"contact.jsp\">Contact</a></li>\r\n"
    						+ "  <li class=\"dropdown\">\r\n"
    						+ "    <a href=\"javascript:void(0)\" class=\"dropbtn\">Solution</a>\r\n"
    						+ "    <div class=\"dropdown-content\">\r\n"
    						+ "      <a href=\"#\">Addbook</a>\r\n"
    						+ "      <a href=\"./ShowAllBookServlet\">Search Book</a>\r\n"
    						+ "      <a href=\"#\">UserLogin</a>\r\n"
    						+ "    </div>\r\n"
    						+ "  </li>\r\n"
    						+ "</ul>\r\n"
    						+ "    </nav>\r\n"
    						+ "    <br><br><br>");
    				//out.print("<body>");
    				out.print("<table border='1'>");
    				out.print("<tr><td>Book Name </td><td>Author name </td><td> Publication Name </td><td> Price of Book</td></tr>");
    				while(rs.next())
    				{
    					out.print(" <tr><td>"+rs.getString(1)+"</td><td> "+rs.getString(2)+"</td><td> "+rs.getString(3)+"</td><td>"+rs.getInt(4)+"</td></tr>");
    				}
    				out.print("</table>");    				
    				out.print("</body>");
    				out.print("</html>");

    			}
    			
    			catch(SQLException e)
    			{
    				e.printStackTrace();
    			}
    			catch(ClassNotFoundException e)
    			{
    				e.printStackTrace();	
    				}
    		
    		}
    		

    		/**
    		 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
    		 */
    		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    			// TODO Auto-generated method stub
    			doGet(request, response);
    		}

    	}
