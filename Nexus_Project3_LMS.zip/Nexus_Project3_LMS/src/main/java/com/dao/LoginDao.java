package com.dao;
import com.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.bean.*;

public class LoginDao {
	public String authUserLogin(LoginBean obj) throws SQLException
	{
		String uname= obj.getUsername();
		String upwd=obj.getPassword();
		Connection con=DBConnection.DataConnection();
		PreparedStatement ps= con.prepareStatement("select uname,upwd from usertb where uname=? and upwd=?");
		ps.setString(1, uname);
		ps.setString(2, upwd);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
			return "sucess";
		return "Invlid username and password";
	}
}
