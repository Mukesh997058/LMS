package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.bean.*;
import com.util.DBConnection;
public class BookDao {
	public String addbook(BookBean bobj) throws SQLException
	{
		String bname=bobj.getBname();
		String aname=bobj.getAname();
		int price=bobj.getPrice();
		String pubname=bobj.getPubname();
		Connection con=DBConnection.DataConnection();
		
		String sql="insert into booktable(bookname,authorname,publication_name,price)VALUES(?,?,?,?)";
		
		PreparedStatement stmt=con.prepareStatement(sql);
		stmt.setString(1, bname);
		stmt.setString(2, aname);
		stmt.setInt(4, price);
		stmt.setString(3, pubname);
		
		int i=stmt.executeUpdate();
		if(i>0)
			return "success";
		else
			return"Record not inserted";

		
	}
}
