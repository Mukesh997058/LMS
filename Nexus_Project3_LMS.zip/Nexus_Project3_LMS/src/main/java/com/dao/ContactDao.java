package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bean.*;
import com.util.DBConnection;

public class ContactDao {
	public String contact(contact cobj) throws SQLException
	{
		String name=cobj.getName();;
		String scname=cobj.getScname();
		String sclocation=cobj.getScname();
		String email=cobj.getEmail();

		int contactno=cobj.getContactno();
		
		Connection con=DBConnection.DataConnection();
		
		String sql="insert into contact(name,scname,sclocation,email,contactno)VALUES(?,?,?,?,?)";
		
		PreparedStatement stmt=con.prepareStatement(sql);
		stmt.setString(1, name);
		stmt.setString(2, scname);
		stmt.setString(3, sclocation);
		stmt.setString(4, email);
		stmt.setInt(5, contactno);
		
		int i=stmt.executeUpdate();
		if(i>0)
			return "success";
		else
			return"Record not inserted";

		
	}
}
