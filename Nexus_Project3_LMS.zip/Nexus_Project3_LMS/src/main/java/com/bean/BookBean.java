package com.bean;

import java.io.Serializable;

public class BookBean implements Serializable
{
	String bname;
	String aname;
	int price;
	String pubname;
	public BookBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookBean(String bname, String aname, int price, String pubname) {
		super();
		this.bname = bname;
		this.aname = aname;
		this.price = price;
		this.pubname = pubname;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getPubname() {
		return pubname;
	}
	public void setPubname(String pubname) {
		this.pubname = pubname;
	}
	@Override
	public String toString() {
		return "BookBean [bname=" + bname + ", aname=" + aname + ", price=" + price + ", pubname=" + pubname + "]";
	}
	

}
