package com.bean;

public class contact {
String name;
String scname;
String sclocation;
String email;
int contactno;
public contact() {
	super();
	// TODO Auto-generated constructor stub
}
public contact(String name, String scname, String sclocation, String email, int contactno) {
	super();
	this.name = name;
	this.scname = scname;
	this.sclocation = sclocation;
	this.email = email;
	this.contactno = contactno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getScname() {
	return scname;
}
public void setScname(String scname) {
	this.scname = scname;
}
public String getSclocation() {
	return sclocation;
}
public void setSclocation(String sclocation) {
	this.sclocation = sclocation;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public int getContactno() {
	return contactno;
}
public void setContactno(int contactno) {
	this.contactno = contactno;
}
@Override
public String toString() {
	return "contact [name=" + name + ", scname=" + scname + ", sclocation=" + sclocation + ", email=" + email
			+ ", contactno=" + contactno + "]";
}

}
